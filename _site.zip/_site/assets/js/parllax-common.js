$(document).ready(function(){
    $('#parallax').parallax({
        invertX: false,
        invertY: false,
        scalarX: 12,
        frictionY: .1
    });
})